package com.dermasense.app

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.appcompat.app.AppCompatActivity
import com.dermasense.app.databinding.ActivityAnalyzingBinding

class AnalyzingActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAnalyzingBinding
    private val handler = Handler(Looper.getMainLooper())

    private val stepDelays = listOf(800L, 1600L, 2400L)
    private val navigateDelay = 3200L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityAnalyzingBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val imageUri = intent.getStringExtra(ScanActivity.EXTRA_IMAGE_URI)
        val symptoms = intent.getStringExtra(ScanActivity.EXTRA_SYMPTOMS) ?: ""

        animateSteps()
        scheduleNavigation(imageUri, symptoms)
    }

    private fun animateSteps() {
        val steps = listOf(
            binding.tvStep1,
            binding.tvStep2,
            binding.tvStep3
        )

        steps.forEachIndexed { index, textView ->
            handler.postDelayed({
                textView.alpha = 1f
                textView.setTextColor(getColor(R.color.text_primary))
            }, stepDelays[index])
        }
    }

    private fun scheduleNavigation(imageUri: String?, symptoms: String) {
        handler.postDelayed({
            if (!isFinishing) {

                val intent = Intent(this, ResultsActivity::class.java).apply {
                    putExtra(ResultsActivity.EXTRA_IMAGE_URI, imageUri)

                    // ❌ FIX: removed invalid reference
                    // putExtra(ResultsActivity.EXTRA_SYMPTOMS, symptoms)

                    putExtra(ResultsActivity.EXTRA_CONDITION, "Insect bite")
                    putExtra(ResultsActivity.EXTRA_SEVERITY, "Low severity")
                    putExtra(ResultsActivity.EXTRA_CONFIDENCE, 85)
                    putExtra(
                        ResultsActivity.EXTRA_DESCRIPTION,
                        "The image appears to show a single, raised, reddish bump on the forearm, " +
                                "consistent with an insect bite."
                    )
                }

                startActivity(intent)
                overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
                finish()
            }
        }, navigateDelay)
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacksAndMessages(null)
    }
}