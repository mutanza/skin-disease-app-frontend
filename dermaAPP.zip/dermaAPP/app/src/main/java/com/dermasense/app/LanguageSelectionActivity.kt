package com.dermasense.app

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.RadioButton
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class LanguageSelectionActivity : AppCompatActivity() {

    private lateinit var rbEnglish: RadioButton
    private lateinit var rbUrdu: RadioButton
    private lateinit var rbRomanUrdu: RadioButton

    private lateinit var btnContinue: Button
    private lateinit var tvFootNote: TextView

    private var selectedLanguage: Language? = null

    enum class Language(
        val code: String,
        val continueLabel: String,
        val footNote: String
    ) {
        ENGLISH(
            "en",
            "Continue →",
            "You can change language anytime in settings"
        ),

        URDU(
            "ur",
            "آگے بڑھیں ←",
            "آپ سیٹنگز میں زبان بدل سکتے ہیں"
        ),

        ROMAN_URDU(
            "roman_ur",
            "Aage Barein →",
            "Aap settings mein language change kar saktay hain"
        )
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_language_selection)

        bindViews()
        setupClicks()

        btnContinue.isEnabled = false
        btnContinue.alpha = 0.5f
    }

    private fun bindViews() {

        rbEnglish = findViewById(R.id.rbEnglish)
        rbUrdu = findViewById(R.id.rbUrdu)
        rbRomanUrdu = findViewById(R.id.rbRomanUrdu)

        btnContinue = findViewById(R.id.btnContinue)
        tvFootNote = findViewById(R.id.tvFootNote)
    }

    private fun setupClicks() {

        rbEnglish.setOnClickListener { selectLanguage(Language.ENGLISH) }
        rbUrdu.setOnClickListener { selectLanguage(Language.URDU) }
        rbRomanUrdu.setOnClickListener { selectLanguage(Language.ROMAN_URDU) }

        btnContinue.setOnClickListener {

            selectedLanguage?.let { language ->

                // 🔥 SAVE LANGUAGE
                LanguageManager.saveLanguage(this, language.code)

                // 🔥 APPLY LANGUAGE BEFORE NEXT SCREEN
                LanguageManager.applyLanguage(this)

                // GO DASHBOARD
                startActivity(
                    Intent(this, DashboardActivity::class.java)
                )

                finish()
            }
        }
    }

    private fun selectLanguage(language: Language) {

        selectedLanguage = language

        resetAll()

        when (language) {
            Language.ENGLISH -> rbEnglish.isChecked = true
            Language.URDU -> rbUrdu.isChecked = true
            Language.ROMAN_URDU -> rbRomanUrdu.isChecked = true
        }

        btnContinue.isEnabled = true
        btnContinue.alpha = 1f

        btnContinue.text = language.continueLabel
        tvFootNote.text = language.footNote
    }

    private fun resetAll() {
        rbEnglish.isChecked = false
        rbUrdu.isChecked = false
        rbRomanUrdu.isChecked = false
    }
}