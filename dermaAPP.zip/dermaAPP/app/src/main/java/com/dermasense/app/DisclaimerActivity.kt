package com.dermasense.app

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.dermasense.app.databinding.ActivityDisclaimerBinding

/**
 * DisclaimerActivity — Important Disclaimer screen
 */
class DisclaimerActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDisclaimerBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityDisclaimerBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnUnderstand.setOnClickListener {

            // Navigate to Language Selection screen
            startActivity(
                Intent(this, LanguageSelectionActivity::class.java)
            )

            overridePendingTransition(
                android.R.anim.fade_in,
                android.R.anim.fade_out
            )

            finish()
        }
    }
}