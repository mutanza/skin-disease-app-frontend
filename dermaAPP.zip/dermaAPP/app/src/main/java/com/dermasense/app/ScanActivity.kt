package com.dermasense.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.dermasense.app.databinding.ActivityScanBinding
import com.yalantis.ucrop.UCrop
import java.io.File

class ScanActivity : AppCompatActivity() {

    private lateinit var binding: ActivityScanBinding

    private var selectedImageUri: Uri? = null
    private var imageUri: Uri? = null

    // 📷 CAMERA
    private val cameraLauncher =
        registerForActivityResult(ActivityResultContracts.TakePicture()) { success ->
            if (success) {
                imageUri?.let {
                    startCrop(it)
                }
            }
        }

    // 🖼 GALLERY
    private val imagePickerLauncher =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
            uri?.let {
                startCrop(it)
            }
        }

    // ✂️ CROP
    private val cropLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->

            if (result.resultCode == RESULT_OK) {

                val resultUri = UCrop.getOutput(result.data!!)

                resultUri?.let {

                    selectedImageUri = it

                    binding.ivPhotoPreview.setImageURI(it)
                    binding.ivPhotoPreview.visibility = View.VISIBLE
                    binding.layoutUploadPlaceholder.visibility = View.GONE

                    updateAnalyzeButtonState()
                }
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        LanguageManager.applyLanguage(this)

        binding = ActivityScanBinding.inflate(layoutInflater)
        setContentView(binding.root)

        onBackPressedDispatcher.addCallback(
            this,
            object : OnBackPressedCallback(true) {
                override fun handleOnBackPressed() {
                    finish()
                }
            }
        )

        // 📸 IMAGE AREA CLICK
        binding.layoutPhotoArea.setOnClickListener {
            showImageOptions()
        }

        // 📝 SYMPTOMS COUNTER
        binding.etSymptoms.addTextChangedListener(object : TextWatcher {

            override fun afterTextChanged(s: Editable?) {
                val count = s?.length ?: 0
                binding.tvCharCount.text = "$count/500"
            }

            override fun beforeTextChanged(
                s: CharSequence?,
                start: Int,
                count: Int,
                after: Int
            ) {
            }

            override fun onTextChanged(
                s: CharSequence?,
                start: Int,
                before: Int,
                count: Int
            ) {
            }
        })

        // 🚀 ANALYZE BUTTON
        binding.btnAnalyze.setOnClickListener {

            val intent = Intent(
                this,
                AnalyzingActivity::class.java
            ).apply {

                putExtra(
                    EXTRA_IMAGE_URI,
                    selectedImageUri?.toString()
                )

                putExtra(
                    EXTRA_SYMPTOMS,
                    binding.etSymptoms.text?.toString() ?: ""
                )
            }

            startActivity(intent)

            overridePendingTransition(
                android.R.anim.fade_in,
                android.R.anim.fade_out
            )
        }

        updateAnalyzeButtonState()
    }

    // ✂️ START CROP
    private fun startCrop(sourceUri: Uri) {

        val destinationUri = Uri.fromFile(
            File(cacheDir, "cropped_image.jpg")
        )

        val intent = UCrop.of(
            sourceUri,
            destinationUri
        )
            .withAspectRatio(1f, 1f)
            .withMaxResultSize(800, 800)
            .getIntent(this)

        cropLauncher.launch(intent)
    }

    // 📌 IMAGE OPTIONS
    private fun showImageOptions() {

        val options = arrayOf(
            getString(R.string.camera),
            getString(R.string.gallery)
        )

        AlertDialog.Builder(this)
            .setTitle(getString(R.string.select_image_source))
            .setItems(options) { _, which ->

                when (which) {

                    0 -> openCamera()

                    1 -> imagePickerLauncher.launch("image/*")
                }
            }
            .show()
    }

    // 📷 OPEN CAMERA
    private fun openCamera() {

        val uri = createImageUri()

        imageUri = uri

        cameraLauncher.launch(uri)
    }

    // 📁 CREATE URI
    private fun createImageUri(): Uri {

        val file = File(
            cacheDir,
            "camera_photo.jpg"
        )

        return androidx.core.content.FileProvider.getUriForFile(
            this,
            "${applicationContext.packageName}.provider",
            file
        )
    }

    // 🔘 BUTTON STATE
    private fun updateAnalyzeButtonState() {

        val hasImage = selectedImageUri != null

        binding.btnAnalyze.isEnabled = hasImage

        binding.btnAnalyze.alpha =
            if (hasImage) 1f else 0.5f
    }

    companion object {
        const val EXTRA_IMAGE_URI = "extra_image_uri"
        const val EXTRA_SYMPTOMS = "extra_symptoms"
    }
}