package com.dermasense.app

import android.net.Uri
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.dermasense.app.databinding.ActivityResultsBinding

/**
 * ResultsActivity — "Your Results" screen (IMG_7468 + IMG_7470)
 * Displays:
 *  - Uploaded skin photo
 *  - Condition name, severity badge, confidence %
 *  - Description paragraph
 *  - Green confidence progress bar
 *  - Medical / Organic tab switcher
 *  - Scrollable list of recommendations
 */
class ResultsActivity : AppCompatActivity() {

    private lateinit var binding: ActivityResultsBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityResultsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Retrieve data from intent
        val imageUri    = intent.getStringExtra(EXTRA_IMAGE_URI)
        val condition   = intent.getStringExtra(EXTRA_CONDITION)   ?: "Unknown condition"
        val severity    = intent.getStringExtra(EXTRA_SEVERITY)    ?: "Low severity"
        val confidence  = intent.getIntExtra(EXTRA_CONFIDENCE, 85)
        val description = intent.getStringExtra(EXTRA_DESCRIPTION) ?: ""

        // Bind data
        imageUri?.let {
            binding.ivSkinPhoto.setImageURI(Uri.parse(it))
        }
        binding.tvCondition.text   = condition
        binding.tvSeverity.text    = severity
        binding.tvConfidence.text  = "$confidence% confidence"
        binding.tvDescription.text = description
        binding.progressBar.progress = confidence

        // Home button
        binding.btnHome.setOnClickListener { finish() }

        // Tab switcher — Medical (default) vs Organic
        binding.btnTabMedical.setOnClickListener  { showMedical()  }
        binding.btnTabOrganic.setOnClickListener  { showOrganic()  }

        showMedical() // default tab
    }

    private fun showMedical() {
        // Tab visual state
        binding.btnTabMedical.setBackgroundResource(R.drawable.bg_tab_selected)
        binding.btnTabOrganic.setBackgroundResource(android.R.color.transparent)

        // Show medical list, hide organic
        binding.layoutMedical.visibility = View.VISIBLE
        binding.layoutOrganic.visibility = View.GONE
    }

    private fun showOrganic() {
        // Tab visual state
        binding.btnTabOrganic.setBackgroundResource(R.drawable.bg_tab_selected)
        binding.btnTabMedical.setBackgroundResource(android.R.color.transparent)

        // Show organic list, hide medical
        binding.layoutOrganic.visibility = View.VISIBLE
        binding.layoutMedical.visibility = View.GONE
    }

    companion object {
        const val EXTRA_IMAGE_URI   = "extra_image_uri"
        const val EXTRA_SYMPTOMS    = "extra_symptoms"
        const val EXTRA_CONDITION   = "extra_condition"
        const val EXTRA_SEVERITY    = "extra_severity"
        const val EXTRA_CONFIDENCE  = "extra_confidence"
        const val EXTRA_DESCRIPTION = "extra_description"
    }
}
