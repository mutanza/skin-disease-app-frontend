import android.content.Context
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity

open class BaseActivity : AppCompatActivity() {

    override fun attachBaseContext(newBase: Context) {

        val prefs: SharedPreferences =
            newBase.getSharedPreferences("settings", MODE_PRIVATE)

        val lang = prefs.getString("lang", "en") ?: "en"

        val context = LocaleHelper.setLocale(newBase, lang)

        super.attachBaseContext(context)
    }
}