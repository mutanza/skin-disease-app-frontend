package com.dermasense.app

import android.content.Context
import android.content.res.Configuration
import java.util.Locale

object LanguageManager {

    private const val PREFS_NAME = "dermasense_prefs"
    private const val KEY_LANGUAGE = "selected_language"

    fun saveLanguage(context: Context, languageCode: String) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_LANGUAGE, languageCode)
            .apply()
    }

    fun getLanguage(context: Context): String {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getString(KEY_LANGUAGE, "en") ?: "en"
    }

    fun applyLanguage(context: Context) {
        val langCode = getLanguage(context)

        val locale = when (langCode) {
            "ur" -> Locale("ur")
            "roman_ur" -> Locale("en") // Roman Urdu workaround
            else -> Locale("en")
        }

        Locale.setDefault(locale)

        val config = Configuration()
        config.setLocale(locale)

        context.resources.updateConfiguration(
            config,
            context.resources.displayMetrics
        )
    }
}