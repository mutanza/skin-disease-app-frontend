package com.dermasense.app

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.dermasense.app.databinding.ActivityDashboardBinding

class DashboardActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDashboardBinding

    override fun onCreate(savedInstanceState: Bundle?) {

        // 🔥 APPLY LANGUAGE FIRST (VERY IMPORTANT)
        LanguageManager.applyLanguage(this)

        super.onCreate(savedInstanceState)
        binding = ActivityDashboardBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupClicks()
    }

    private fun setupClicks() {

        // Hero card click
        binding.cardScanHero.setOnClickListener { openScan() }

        // Medical advice tile
        binding.cardMedical.setOnClickListener { openScan() }

        // Organic remedies tile
        binding.cardOrganic.setOnClickListener { openScan() }

        // Start Scan button
        binding.btnStartScan.setOnClickListener { openScan() }
    }

    private fun openScan() {
        startActivity(Intent(this, ScanActivity::class.java))
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
    }
}